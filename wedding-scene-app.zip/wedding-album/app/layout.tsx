import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Our Wedding Scene',
  description: 'A shared camera roll — nobody sees a photo until the reveal.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-ink text-cream min-h-screen">{children}</body>
    </html>
  );
}
