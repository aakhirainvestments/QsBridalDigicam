'use client';

import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function CameraCapture({
  eventId,
  guestId,
  shotsTaken,
  shotLimit,
  onShotTaken,
}: {
  eventId: string;
  guestId: string;
  shotsTaken: number;
  shotLimit: number;
  onShotTaken: (newCount: number) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [facing, setFacing] = useState<'environment' | 'user'>('environment');
  const remaining = shotLimit - shotsTaken;

  useEffect(() => {
    let stream: MediaStream | null = null;

    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing },
          audio: false,
        });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (e) {
        setError('Camera access was denied. Enable camera permission for this site and reload.');
      }
    }
    start();

    return () => {
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [facing]);

  async function takeShot() {
    if (remaining <= 0 || uploading) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    setUploading(true);
    setError(null);

    canvas.toBlob(
      async (blob) => {
        if (!blob) {
          setUploading(false);
          setError('Could not process the photo, try again.');
          return;
        }
        try {
          const path = `${eventId}/${guestId}/${crypto.randomUUID()}.jpg`;
          const { error: uploadErr } = await supabase.storage
            .from('wedding-photos')
            .upload(path, blob, { contentType: 'image/jpeg' });
          if (uploadErr) throw uploadErr;

          const { error: insertErr } = await supabase
            .from('photos')
            .insert({ event_id: eventId, guest_id: guestId, storage_path: path });
          if (insertErr) throw insertErr;

          const newCount = shotsTaken + 1;
          const { error: updateErr } = await supabase
            .from('guests')
            .update({ shots_taken: newCount })
            .eq('id', guestId);
          if (updateErr) throw updateErr;

          onShotTaken(newCount);
        } catch (e) {
          setError('Upload failed — check your connection and try again.');
        } finally {
          setUploading(false);
        }
      },
      'image/jpeg',
      0.75
    );
  }

  if (remaining <= 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-16 text-center px-6">
        <p className="text-xl font-semibold">You've used all {shotLimit} of your shots 🎞️</p>
        <p className="text-cream/70">
          That's everyone's roll, honestly — go enjoy the rest of the night. The album unlocks for
          everyone once the reveal timer hits zero.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4 py-4">
      <div className="relative w-full max-w-sm aspect-[3/4] rounded-2xl overflow-hidden bg-black">
        <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
        <div className="absolute top-3 right-3 bg-black/60 rounded-full px-3 py-1 text-sm font-mono">
          {remaining} left
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />

      {error && <p className="text-red-400 text-sm max-w-sm text-center">{error}</p>}

      <div className="flex items-center gap-6">
        <button
          onClick={() => setFacing((f) => (f === 'environment' ? 'user' : 'environment'))}
          className="text-cream/70 text-sm underline"
        >
          Flip camera
        </button>
        <button
          onClick={takeShot}
          disabled={uploading}
          className="w-16 h-16 rounded-full bg-cream disabled:opacity-50 active:scale-95 transition"
          aria-label="Take photo"
        />
      </div>
      {uploading && <p className="text-cream/60 text-sm">Saving…</p>}
    </div>
  );
}
