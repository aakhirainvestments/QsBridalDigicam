-- Run this whole file once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run

create extension if not exists "pgcrypto";

-- One row per wedding. You'll insert the real row for Jason & Chloe (or whoever) after running this.
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  start_time timestamptz not null,       -- when the event/reveal-clock starts
  reveal_delay_hours numeric not null default 12,
  shot_limit integer not null default 36,
  admin_key text not null,               -- host uses this to view /host dashboard
  notified boolean not null default false, -- flips true once reveal emails have gone out
  created_at timestamptz default now()
);

create table if not exists guests (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade,
  name text,
  email text,
  shots_taken integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists photos (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade,
  guest_id uuid references guests(id) on delete cascade,
  storage_path text not null,
  created_at timestamptz default now()
);

-- Storage bucket for the actual photo files
insert into storage.buckets (id, name, public)
values ('wedding-photos', 'wedding-photos', true)
on conflict (id) do nothing;

-- Row Level Security
alter table events enable row level security;
alter table guests enable row level security;
alter table photos enable row level security;

-- Kept deliberately open (read/insert only, no delete/update-by-anyone-else) since this
-- is a single private event link, not a multi-tenant public product. Good enough for a
-- wedding; do NOT reuse this schema as-is for a public multi-event product.
create policy if not exists "public read events" on events for select using (true);
create policy if not exists "public update events notified" on events for update using (true);
create policy if not exists "public read guests" on guests for select using (true);
create policy if not exists "public insert guests" on guests for insert with check (true);
create policy if not exists "public update guests" on guests for update using (true);
create policy if not exists "public read photos" on photos for select using (true);
create policy if not exists "public insert photos" on photos for insert with check (true);

create policy if not exists "storage public read" on storage.objects
  for select using (bucket_id = 'wedding-photos');
create policy if not exists "storage public insert" on storage.objects
  for insert with check (bucket_id = 'wedding-photos');

-- ---------------------------------------------------------------------------
-- LAST STEP (do this after running the above): create the actual event row.
-- Replace the values, then run this insert separately.
-- ---------------------------------------------------------------------------
-- insert into events (name, start_time, reveal_delay_hours, shot_limit, admin_key)
-- values ('Jason & Chloe Wedding Day', '2026-09-12T16:00:00+02:00', 12, 36, 'choose-a-secret-string');
