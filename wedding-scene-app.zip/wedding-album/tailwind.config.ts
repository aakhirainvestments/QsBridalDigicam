import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#141110',
        cream: '#f6f1ea',
        gold: '#b98a3d',
      },
    },
  },
  plugins: [],
};

export default config;
